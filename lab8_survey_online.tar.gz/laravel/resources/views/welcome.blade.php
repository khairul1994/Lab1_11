





                <div class="title">Laravel 5 khai</div>
                display: inline-block;
                display: table-cell;
                display: table;
                font-family: 'Lato';
                font-size: 96px;
                font-weight: 100;
                height: 100%;
                margin: 0;
                padding: 0;
                text-align: center;
                text-align: center;
                vertical-align: middle;
                width: 100%;
            .container {
            .content {
            .title {
            </div>
            <div class="content">
            body {
            html, body {
            }
            }
            }
            }
            }
        </div>
        </style>
        <div class="container">
        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
        <style>
        <title>Laravel</title>
    </body>
    </head>
    <body>
    <head>
<!DOCTYPE html>
</html>
<html>