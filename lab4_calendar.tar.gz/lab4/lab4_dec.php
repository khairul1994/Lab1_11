<!DOCTYPE>
<html>
<title>Resident-Calendar</title>
<body>
<section id="header">
<h1>
<a href="" target="_self"><</a>&nbspDecember 2015&nbsp
<a href="lab4_jan.php" target="_self">></a>
</h1>
</section>

<section id ="calendar">
<table border="1" style="width:50%">
	<tr>
		<td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td>	
	</tr>
	<tr>
		<td></td><td></td>
		<td><a href="event.php?m=12&d=1" target="_self">1</a></td>
		<td><a href="event.php?m=12&d=2" target="_self">2</a></td>
		<td><a href="event.php?m=12&d=3" target="_self">3</a></td>
		<td><a href="event.php?m=12&d=4" target="_self">4</a></td>
		<td><a href="event.php?m=12&d=5" target="_self">5</a></td>	
	</tr>
	<tr>
		<td><a href="event.php?m=12&d=6" target="_self">6</a></td>
		<td><a href="event.php?m=12&d=7" target="_self">7</a></td>
		<td><a href="event.php?m=12&d=8" target="_self">8</a></td>
		<td><a href="event.php?m=12&d=9" target="_self">9</a></td>
		<td><a href="event.php?m=12&d=10" target="_self">10</a></td>
		<td><a href="event.php?m=12&d=11" target="_self">11</a></td>
		<td><a href="event.php?m=12&d=12" target="_self">12</a></td>
	</tr>
	<tr>
		<td><a href="event.php?m=12&d=13" target="_self">13</a></td>
		<td><a href="event.php?m=12&d=14" target="_self">14</a></td>
		<td><a href="event.php?m=12&d=15" target="_self">15</a></td>
		<td><a href="event.php?m=12&d=16" target="_self">16</a></td>
		<td><a href="event.php?m=12&d=17" target="_self">17</a></td>
		<td><a href="event.php?m=12&d=18" target="_self">18</a></td>
		<td><a href="event.php?m=12&d=19" target="_self">19</a></td>
	</tr>
	<tr>
		<td><a href="event.php?m=12&d=20" target="_self">20</a></td>
		<td><a href="event.php?m=12&d=21" target="_self">21</a></td>
		<td><a href="event.php?m=12&d=22" target="_self">22</a></td>
		<td><a href="event.php?m=12&d=23" target="_self">23</a></td>
		<td><a href="event.php?m=12&d=24" target="_self">24</a></td>
		<td><a href="event.php?m=12&d=25" target="_self">25</a></td>
		<td><a href="event.php?m=12&d=26" target="_self">26</a></td>
	</tr>
	<tr>
		<td><a href="event.php?m=12&d=27" target="_self">27</a></td>
		<td><a href="event.php?m=12&d=28" target="_self">28</a></td>
		<td><a href="event.php?m=12&d=29" target="_self">29</a></td>
		<td><a href="event.php?m=12&d=30" target="_self">30</a></td>
		<td><a href="event.php?m=12&d=31" target="_self">31</a></td>
		<td></td><td></td>
	</tr>
	
</table>



</section>


</body>

<style>

#header {
	text-transform: uppercase;
}



</style>
</html>
