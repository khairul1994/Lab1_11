<?php
session_start();
?>
<!DOCTYPE>
<html>
<?php

$nav=$_GET['nav'];
if ($nav == 'p') {
   include 'lab4_dec.php'; exit;}
if ($nav == 'n') {
   include 'lab4_feb.php'; exit;}


?>
<h1>
<?php

$month=$_GET['m'];
$date=$_GET['d'];
$_SESSION['month']=$month;
$_SESSION['date']=$date;

if ($_SESSION['month']=='1') {
	echo 'Events on '.$_SESSION['date'].' January 2016';
}
if ($_SESSION['month']=='2') {
	echo 'Events on '.$_SESSION['date'].' February 2016';
}
if ($_SESSION['month']=='12') {
	echo 'Events on '.$_SESSION['date'].' December 2016';
}
?>

</h1>
<body>
<p id="event_list"></p>

<script>
	var arr1= [];
	function CreateEvent() {
	var inputs = document.getElementById("txtarea").value;
	var b=0;
	var events="";
		
	arr1.push(inputs);
	
	for (b=0;b<arr1.length;b++){
		events+="<li>"+arr1[b]+"</li>";
	} 
	
	document.getElementById("event_list").innerHTML=events;
	document.getElementById("txtarea").value='';
	}
</script>




<textarea rows="4" cols="50" wrap="soft" id="txtarea"></textarea>
<br><br>&nbsp
<button type="button" onclick="CreateEvent()">Submit</button>



</body>

<style>

p {
   padding:10px;
 }

h1 {
   font-family: Arial;
   font-weight:bold;
   font-size:medium;
   position: static;	
}

textarea {
	resize: none;
	
}
</style>



</html>

